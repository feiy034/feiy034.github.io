//Events
//$(selector).eventName(function)
function myFunction(){
  //here's my code
}
$('nav span').hover(function(){
  console.log($(this).css('color'))
  if($(this).css('color') == "rgb(0, 0, 255)"){
    $(this).css('color', 'pink')
  } else {
    $(this).css('color', 'blue')
  }
})
$('nav span').click(function(){
  if($(this).text() == 'WOW!'){
    $(this).text($(this).attr('data-original'))
  } else{
    $(this).attr('data-original', $(this).text())
  $(this).text('WOW!')
  }
  
})
function choice(arr){
  return arr[Math.floor(Math.random() * arr.length)]
}